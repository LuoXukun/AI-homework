#include "net.hpp"

MluConfig mluConfig = MluConfig();

CnmlNet::CnmlNet(int core_num, cnmlCoreVersion_t core_version) {
    cnmlInit(0);
    cnrtDev_t dev;
    cnrtGetDeviceHandle(&dev, 0);
    cnrtSetCurrentDevice(dev);
    _outputShape.resize(4);
    _isFirstLayer = true;
    mluConfig.setCoreNum(core_num);
    mluConfig.setCoreVersion(core_version);
    std::cout << "CORE NUM: " << mluConfig.getCoreNum() << std::endl;
    std::cout << "CORE VERSION: " << mluConfig.getCoreVersion() << std::endl;
}

CnmlNet::~CnmlNet() {
    for (unsigned int i = 0; i < _layerList.size(); i++) {
        delete _layerList[i].second;
    }
}

void CnmlNet::setInputShape(int dim_1, int dim_2, int dim_3, int dim_4) {
    if (_inputShape.empty()) {
        _inputShape.resize(4);
    }
    _inputShape[0] = dim_1;
    _inputShape[1] = dim_2;
    _inputShape[2] = dim_3;
    _inputShape[3] = dim_4;
}

void CnmlNet::createConvLayer(string layer_name,
                              int out_channel, 
                              int kernel_size,
                              int stride,
                              int dilation,
                              int pad,
                              QuantParam quant_param) {
    vector<int>* input_shape;

    if (_isFirstLayer) {
        if (_inputShape.empty()) {
            std::clog << "ERROR : The input shape is empty ! You should set input shape first .\n";
            exit(1);
        }
        input_shape = &_inputShape;
        std::cout << "input_shape: [" << _inputShape[0] << " " 
                                   << _inputShape[1] << " "
                                   << _inputShape[2] << " "
                                   << _inputShape[3] << "]\n";
        _isFirstLayer = false;
    } else {
        input_shape = new vector<int>(_outputShape);
    }

    std::cout << "creating conv layer ..." << std::endl;

    int out_height=((*input_shape)[2] + 2 * pad - kernel_size)/stride + 1;
    int out_width=((*input_shape)[3] + 2 * pad - kernel_size)/stride + 1;

    _outputShape[0] = (*input_shape)[0];
    _outputShape[1] = out_channel;
    _outputShape[2] = out_height;
    _outputShape[3] = out_width;

    std::cout << "output_shape: [" << _outputShape[0] << " " 
                                   << _outputShape[1] << " "
                                   << _outputShape[2] << " "
                                   << _outputShape[3] << "]\n";
    vector<int> kernel_vector= {kernel_size, kernel_size};
    vector<int> stride_vector = {stride, stride};
    vector<int> dilation_vector = {dilation, dilation};
    vector<int> pad_vector = {pad, pad, pad, pad};
    int input_position = quant_param.position;
    float input_scale = quant_param.scale;

    CnmlConvLayer * convlayer = new CnmlConvLayer(*input_shape, 
                                                  _outputShape, 
                                                  kernel_vector,
                                                  stride_vector,
                                                  dilation_vector,
                                                  pad_vector,
                                                  input_position, 
                                                  input_scale);
    _isParamLoaded.push_back(0);
    _layerList.push_back(make_pair(layer_name, convlayer));
    _layerTypesList.push_back(CONVOLUTION);
}

void CnmlNet::createMlpLayer(string layer_name,
                             int output_num,
                             QuantParam quant_param){
    vector<int>* input_shape;

    if (_isFirstLayer) {
        if (_inputShape.empty()) {
            std::clog << "ERROR : The input shape is empty ! You should set input shape first .\n";
            exit(1);
        }
        input_shape = &_inputShape;
        std::cout << "input_shape: [" << _inputShape[0] << " " 
                                   << _inputShape[1] << " "
                                   << _inputShape[2] << " "
                                   << _inputShape[3] << "]\n";
        _isFirstLayer = false;
    } else {
        input_shape = new vector<int>(_outputShape);
    }

    std::cout << "creating mlp layer ..." << std::endl;

    _outputShape[0] = (*input_shape)[0];
    _outputShape[1] = output_num;
    _outputShape[2] = 1;
    _outputShape[3] = 1;

    std::cout << "output_shape: [" << _outputShape[0] << " " 
                                   << _outputShape[1] << " "
                                   << _outputShape[2] << " "
                                   << _outputShape[3] << "]\n";
    int input_position = quant_param.position;
    float input_scale = quant_param.scale;
    
    CnmlMlpLayer * mlplayer = new CnmlMlpLayer(*input_shape, 
                                               _outputShape,
                                               input_position, 
                                               input_scale);
    _isParamLoaded.push_back(0);
    _layerList.push_back(make_pair(layer_name, mlplayer));
    _layerTypesList.push_back(MLP);
}

void CnmlNet::createReLuLayer(string layer_name) {
    vector<int>* input_shape;

    if (_isFirstLayer) {
        if (_inputShape.empty()) {
            std::clog << "ERROR : The input shape is empty ! You should set input shape first .\n";
            exit(1);
        }
        input_shape = &_inputShape;
        std::cout << "input_shape: [" << _inputShape[0] << " " 
                                   << _inputShape[1] << " "
                                   << _inputShape[2] << " "
                                   << _inputShape[3] << "]\n";
        _isFirstLayer = false;
    } else {
        input_shape = &_outputShape;
    }

    std::cout << "creating relu layer ..." << std::endl;

    _outputShape[0] = (*input_shape)[0];
    _outputShape[1] = (*input_shape)[1];
    _outputShape[2] = (*input_shape)[2];
    _outputShape[3] = (*input_shape)[3];

    std::cout << "output_shape: [" << _outputShape[0] << " " 
                                   << _outputShape[1] << " "
                                   << _outputShape[2] << " "
                                   << _outputShape[3] << "]\n";

    CnmlReLuLayer * relulayer = new CnmlReLuLayer(*input_shape);
    _isParamLoaded.push_back(0);
    _layerList.push_back(make_pair(layer_name, relulayer));
    _layerTypesList.push_back(RELU);
}

void CnmlNet::createSoftmaxLayer(string layer_name, int axis) {
    vector<int>* input_shape;

    if (_isFirstLayer) {
        if (_inputShape.empty()) {
            std::clog << "ERROR : The input shape is empty ! You should set input shape first .\n";
            exit(1);
        }
        input_shape = &_inputShape;
        std::cout << "input_shape: [" << _inputShape[0] << " " 
                                   << _inputShape[1] << " "
                                   << _inputShape[2] << " "
                                   << _inputShape[3] << "]\n";
        _isFirstLayer = false;
    } else {
        input_shape = &_outputShape;
    }

    std::cout << "creating softmax layer ..." << std::endl;

    _outputShape[0] = (*input_shape)[0];
    _outputShape[1] = (*input_shape)[1];
    _outputShape[2] = (*input_shape)[2];
    _outputShape[3] = (*input_shape)[3];

    std::cout << "output_shape: [" << _outputShape[0] << " " 
                                   << _outputShape[1] << " "
                                   << _outputShape[2] << " "
                                   << _outputShape[3] << "]\n";

    CnmlSoftmaxLayer * softmaxlayer = new CnmlSoftmaxLayer(*input_shape, axis);
    _isParamLoaded.push_back(0);
    _layerList.push_back(make_pair(layer_name, softmaxlayer));
    _layerTypesList.push_back(SOFTMAX);
}

void CnmlNet::createPoolingLayer(string layer_name,
                                 int kernel_size, 
                                 int stride) {
    vector<int>* input_shape;

    if (_isFirstLayer) {
        if (_inputShape.empty()) {
            std::clog << "ERROR : The input shape is empty ! You should set input shape first .\n";
            exit(1);
        }
        input_shape = &_inputShape;
        std::cout << "input_shape: [" << _inputShape[0] << " " 
                                   << _inputShape[1] << " "
                                   << _inputShape[2] << " "
                                   << _inputShape[3] << "]\n";
        _isFirstLayer = false;
    } else {
        input_shape = new vector<int>(_outputShape);
    }

    std::cout << "creating pooling layer ..." << std::endl;

    const int pooled_height = static_cast<int>(floor(static_cast<float>(
            (*input_shape)[2] - kernel_size) /
          stride)) + 1;
    const int pooled_width = static_cast<int>(floor(static_cast<float>(
            (*input_shape)[3] - kernel_size) /
          stride)) + 1;

    _outputShape[0] = (*input_shape)[0];
    _outputShape[1] = (*input_shape)[1];
    _outputShape[2] = pooled_height;
    _outputShape[3] = pooled_width;

    std::cout << "output_shape: [" << (*input_shape)[0] << " " 
                                   << (*input_shape)[1] << " "
                                   << pooled_height << " "
                                   << pooled_width << "]\n";

    vector<int> kernel_vector = {kernel_size, kernel_size};
    vector<int> stride_vector = {stride, stride};

    CnmlPoolingLayer * poolinglayer = new CnmlPoolingLayer(*input_shape,
                                                           kernel_vector,
                                                           stride_vector);
    _isParamLoaded.push_back(0);
    _layerList.push_back(make_pair(layer_name, poolinglayer));
    _layerTypesList.push_back(POOL);
}

void CnmlNet::createFlattenLayer(string layer_name,
                                 vector<int> output_shape) {
    vector<int>* input_shape;

    if (_isFirstLayer) {
        if (_inputShape.empty()) {
            std::clog << "ERROR : The input shape is empty ! You should set input shape first .\n";
            exit(1);
        }
        input_shape = &_inputShape;
        std::cout << "input_shape: [" << _inputShape[0] << " " 
                                   << _inputShape[1] << " "
                                   << _inputShape[2] << " "
                                   << _inputShape[3] << "]\n";
        _isFirstLayer = false;
    } else {
        input_shape = new vector<int>(_outputShape);
    }

    std::cout << "creating flatten layer ..." << std::endl;

    _outputShape[0] = output_shape[0];
    _outputShape[1] = output_shape[1];
    _outputShape[2] = output_shape[2];
    _outputShape[3] = output_shape[3];

    std::cout << "output_shape: [" << output_shape[0] << " " 
                                   << output_shape[1] << " "
                                   << output_shape[2] << " "
                                   << output_shape[3] << "]\n";
    
    CnmlFlattenLayer * flattenlayer = new CnmlFlattenLayer(*input_shape,
                                                           _outputShape);
    _isParamLoaded.push_back(0);
    _layerList.push_back(make_pair(layer_name, flattenlayer));
    _layerTypesList.push_back(FLATTEN);
}

vector<float> CnmlNet::forward(vector<float> input_data) {
    // malloc cnml tensor
    void *input_mlu_ptr;
    cnrtMalloc(&input_mlu_ptr, input_data.size() * sizeof(int16_t));
    // converts data type for mlu computing
    vector<int16_t> input_cpu_ptr(input_data.size(), 0);
    cnrtCastDataType(input_data.data(), CNRT_FLOAT32, input_cpu_ptr.data(), CNRT_FLOAT16, input_data.size(), NULL);

    // copy input to cnml buffer
    cnrtMemcpy(input_mlu_ptr, input_cpu_ptr.data(), input_data.size() * sizeof(int16_t), CNRT_MEM_TRANS_DIR_HOST2DEV);

    cnrtQueue_t queue;
    cnrtCreateQueue(&queue);

    void *output_mlu_ptr = input_mlu_ptr;
    for (unsigned int i = 0; i < _layerList.size(); i++) {
        if (_layerTypesList[i] == CONVOLUTION) {
            if (_isParamLoaded[i] == 0) {
                std::clog << "ERROR: param of layer " << _layerList[i].first << " is not loaded !\n";
                exit(1);
            }
            CnmlConvLayer* convlayer = static_cast<CnmlConvLayer*>(_layerList[i].second);
            output_mlu_ptr = convlayer->forward(output_mlu_ptr, queue);
        } else if (_layerTypesList[i] == MLP) {
            CnmlMlpLayer* mlplayer = static_cast<CnmlMlpLayer*>(_layerList[i].second);
            output_mlu_ptr = mlplayer->forward(output_mlu_ptr, queue);
        } else if (_layerTypesList[i] == RELU) {
            CnmlReLuLayer* relulayer = static_cast<CnmlReLuLayer*>(_layerList[i].second);
            output_mlu_ptr = relulayer->forward(output_mlu_ptr, queue);
        } else if (_layerTypesList[i] == SOFTMAX) {
            CnmlSoftmaxLayer* softmaxlayer = static_cast<CnmlSoftmaxLayer*>(_layerList[i].second);
            output_mlu_ptr = softmaxlayer->forward(output_mlu_ptr, queue);
        } else if (_layerTypesList[i] == POOL) {
            CnmlPoolingLayer* poolinglayer = static_cast<CnmlPoolingLayer*>(_layerList[i].second);
            output_mlu_ptr = poolinglayer->forward(output_mlu_ptr, queue);
        } else if (_layerTypesList[i] == FLATTEN) {
            CnmlFlattenLayer* flattenlayer = static_cast<CnmlFlattenLayer*>(_layerList[i].second);
            output_mlu_ptr = flattenlayer->forward(output_mlu_ptr, queue);
        }
    }

    cnrtSyncQueue(queue);
    cnrtDestroyQueue(queue);

    int output_size = _outputShape[0] * _outputShape[1] * _outputShape[2] * _outputShape[3];

    vector<int16_t> output_cpu_ptr(output_size, 0);
    vector<float> output_cpu_data(output_size, 0);
    // copy output to cpu
    cnrtMemcpy(output_cpu_ptr.data(), output_mlu_ptr, output_size * sizeof(int16_t),
                CNRT_MEM_TRANS_DIR_DEV2HOST);

    // cast datatype to float
    cnrtCastDataType(output_cpu_ptr.data(), CNRT_FLOAT16, output_cpu_data.data(), CNRT_FLOAT32, output_size, NULL);

    cnrtFree(input_mlu_ptr);

    return output_cpu_data;
}

void CnmlNet::loadParams(int layer_id,
                         vector<float> filter_data, 
                         vector<float> bias_data, 
                         QuantParam quant_param) {
    std::cout << "loading params for layer " << _layerList[layer_id].first << " ..." << std::endl;
    std::cout << "weight size: " << filter_data.size() << std::endl;
    int filter_position = quant_param.position;
    float filter_scale = quant_param.scale;

    if (_layerTypesList[layer_id] == CONVOLUTION) {
        CnmlConvLayer* convlayer = static_cast<CnmlConvLayer*>(_layerList[layer_id].second);
        convlayer->loadParam(filter_data, bias_data, filter_position, filter_scale);
    } else if (_layerTypesList[layer_id] == MLP) {
        CnmlMlpLayer* mlplayer = static_cast<CnmlMlpLayer*>(_layerList[layer_id].second);
        mlplayer->loadParam(filter_data, bias_data, filter_position, filter_scale);
    } else {
        std::clog << "ERROR : This layer is not conv or mlp !\n";
        std::clog << "\tlayer name is : " << _layerList[layer_id].first << std::endl;
        exit(1);
    }
    _isParamLoaded[layer_id] = 1;
}

string CnmlNet::getLayerName(int layer_id) {
    return _layerList[layer_id].first;
}

int CnmlNet::size() {
    return _layerList.size();
}

bool CnmlNet::needToBeQuantized(int layer_id) {
    return _layerTypesList[layer_id] == CONVOLUTION || _layerTypesList[layer_id] == MLP;
}